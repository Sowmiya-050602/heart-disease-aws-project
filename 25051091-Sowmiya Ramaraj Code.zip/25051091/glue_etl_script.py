import sys
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import col, when

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

RAW = "s3://heart-disease-raw-sr1/data/heart.csv"
OUT = "s3://heart-disease-processed-sr2/"

# Load data
df = spark.read.csv(RAW, header=True, inferSchema=True)

# Clean data
df = df.dropna()
df = df.withColumn("target", when(col("target") > 0, 1).otherwise(0))

cols = df.columns
cols = ["target"] + [c for c in cols if c != "target"]
df = df.select(*cols)

# Train-test split
train, test = df.randomSplit([0.8, 0.2], seed=42)

train.write.mode("overwrite").csv(OUT + "train/", header=False)
test.write.mode("overwrite").csv(OUT + "test/", header=False)